from distutils.core import setup
setup(
name = 'nester',
version = '1.0.0',
py_modules = ['nester'],
author = 'test',
author_email = 'test@test.com',
desciption = 'A simple printer of nested lists'
)
